<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body>
   <?php

$i=5;
if($i=0)
        echo"this is true";
else
        echo"this is false"
        
?>
  </body>
</html>