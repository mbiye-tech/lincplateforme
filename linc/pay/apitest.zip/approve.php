<?php
//echo "<h1>Approve page</h1>";
//echo var_dump($_REQUEST);

header("Content-type: application/json");
$xml = base64_decode($_POST['xmlmsg']);
$xml = simplexml_load_string($xml);
$json = json_encode($xml);
$array = json_decode($json,TRUE);

file_put_contents('logs.txt', "\n$json", FILE_APPEND);

echo $json;