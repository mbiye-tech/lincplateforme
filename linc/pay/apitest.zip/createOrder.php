<?php
// include script with functions
include 'plugin_Ecom.php';
// getting response with given parameters
$response = createOrder('CreateOrder',  //Operation
						'EN',  //Language
						'TEST_ECOM449',  //MerchantID
						'500',  //Amount, two last digits are decimalsAmount, two last digits are decimals
						'840',  //Currency code 978-Eur, 840-USD, 936-GHC, 976-CDF
						'Your order description',  //Description
						'https://apitest.mnonga.repl.co/approve.php', //ApproveURL
						'https://apitest.mnonga.repl.co/cancel.php',  //CancelURL
						'https://apitest.mnonga.repl.co/decline.php',  //DeclineURL
						'Purchase',  //OrderType
						'nongamichee2@gmail.com', //order email
						'49555666777', //order phone number if any
						'156', //order shipping country code
						'Kinshasa', //order shipping city if any
						'32', //order delivery period in days if any
						'E643C1426056', //merchant external ID for the order if any
						'Kinshasa', //order shipping state if any
						'000000', //order zip code
						'Kinshasa/Limete'); // order shipping address
						
?>